#pragma once

class C3pResult
{
public:
	virtual ~C3pResult();

	void Init();

	void Clear();

	void InitMatrix();

};