///////////////////////////////////////////////////////////
//  C3pRwXf2.cpp
//  Implementation of the Class C3pRwXf2
//  Created on:      18-5��-2017 8:07:40
//  Original author: open2
///////////////////////////////////////////////////////////

#include "C3pRwXf2.h"


void C3pRwXf2::doLoad(CDevBase* vDevice)
{

	string vStr;
	_variant_t vValue;
	C3pDevXf2 * vDev;
	
	vDev = dynamic_cast<C3pDevXf2 *>(vDevice);
	
	C3pRwTwo::doLoad(vDevice);
	
		
	RwAdo->GetFieldValue("SN", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetTkN(vValue.dblVal); //˫����
	};

	RwAdo->GetFieldValue("TkN", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetTkN(vValue.dblVal); //˫����
	};
	
	RwAdo->GetFieldValue("UacN", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetUacN(vValue.dblVal); //˫����
	};
				
	RwAdo->GetFieldValue("UvN", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetUvN(vValue.dblVal); //˫����
	};

	RwAdo->GetFieldValue("Ukp", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetUkp(vValue.dblVal); //˫����
	};
	
	RwAdo->GetFieldValue("Urp", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetUrp(vValue.dblVal); //˫����
	};


	RwAdo->GetFieldValue("dTkN", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetdTkN(vValue.dblVal); //˫����
	};

	RwAdo->GetFieldValue("PhaseShift", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetTkN(vValue.dblVal); //˫����
	};

	/*
	RwAdo->GetFieldValue("Std_Lt", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetStd_Lt(vValue.dblVal); //˫����
	};

	RwAdo->GetFieldValue("Dis_dLt", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetDis_dLt(vValue.dblVal); //˫����
	};
	*/

	RwAdo->GetFieldValue("deltaLtA", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetdLtA(vValue.dblVal); //˫����
	};

	RwAdo->GetFieldValue("deltaLtB", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetdLtB(vValue.dblVal); //˫����
	};

	RwAdo->GetFieldValue("deltaLtC", vValue);
	if (vValue.vt != VT_NULL)
	{
		vDev->SetdLtC(vValue.dblVal); //˫����
	};


}


void C3pRwXf2::doSave(CDevBase* vDevice)
	{

	string vStr;
	_variant_t vValue;
	C3pDevXf2 * vDev;
	
	vDev = dynamic_cast<C3pDevXf2 *>(vDevice);
	
	C3pRwTwo::doSave(vDevice);
	
	SqlStr = SqlStr + ",";
	SqlParam = SqlParam + ",";
	
	SqlStr = SqlStr + "Ukp, ";
	SqlParam = SqlParam +GetString(vDev->GetUkp()) + ",";
	
	SqlStr = SqlStr + "Urp, ";
	SqlParam = SqlParam +GetString(vDev->GetUrp()) + ",";

		
	SqlStr = SqlStr + "SN, ";
	SqlParam = SqlParam +GetString(vDev->GetSN()) + ",";
	
	SqlStr = SqlStr + "TkN, ";
	SqlParam = SqlParam +GetString(vDev->GetTkN()) + ",";
	
	SqlStr = SqlStr + "UacN, ";
	SqlParam = SqlParam +GetString(vDev->GetUacN()) + ",";
	
	SqlStr = SqlStr + "UvN, ";
	SqlParam = SqlParam +GetString(vDev->GetUvN()) + ",";

	SqlStr = SqlStr + "PhaseShift, ";
	SqlParam = SqlParam +GetString(vDev->GetPhaseShift()) + ",";
	
	SqlStr = SqlStr + "dTkN, ";
	SqlParam = SqlParam +GetString(vDev->GetdTkN()) + ",";
	
	//SqlStr = SqlStr + "Std_Lt, ";
	//SqlParam = SqlParam +GetString(vDev->GetStd_Lt()) + ",";

	//SqlStr = SqlStr + "Dis_dLt, ";
	//SqlParam = SqlParam +GetString(vDev->GetDis_dLt()) + ",";
	
	SqlStr = SqlStr + "deltaLtA, ";
	SqlParam = SqlParam +GetString(vDev->GetdLtA()) + ",";
	
	SqlStr = SqlStr + "deltaLtB, ";
	SqlParam = SqlParam +GetString(vDev->GetdLtB()) + ",";

	SqlStr = SqlStr + "deltaLtC ";
	SqlParam = SqlParam +GetString(vDev->GetdLtC());



}