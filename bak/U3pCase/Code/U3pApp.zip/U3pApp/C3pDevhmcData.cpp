///////////////////////////////////////////////////////////
//  C3pDevhmcData.cpp
//  Implementation of the Class C3pDevhmcData
//  Created on:      18-5��-2017 11:51:00
//  Original author: open2
///////////////////////////////////////////////////////////

#include "C3pDevhmcData.h"

C3pDevhmcData::~C3pDevhmcData()
{
	delete[] hData;
	hData = nullptr;
}

void C3pDevhmcData::Init()
{
	SetStaCount(1);
	SetDotCount(0);

	//
	nStaDim = 0;
	nCaseDim = 0;
	nPdPreDim = 0;
	
	hData = nullptr;

}

void C3pDevhmcData::Init(int vStaDim, int vCaseDim, int vPdPreDim)
{
	nStaDim = vStaDim;
	nCaseDim = vCaseDim;
	nPdPreDim = vPdPreDim;

	int vN = nStaDim*nCaseDim*nPdPreDim;
	hData = new struct_3p_hData[vN];

}
