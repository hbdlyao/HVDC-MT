#pragma once

#include "C3pCalTwo.h"

class C3pCalConvertor : public C3pCalTwo
{
	void Prepare();

	void Update3pData(int vLoop) override;
};