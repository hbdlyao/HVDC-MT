
#include "C3pResult.h"

C3pResult::~C3pResult()
{
}

void C3pResult::Init()
{
}

void C3pResult::Clear()
{
}

void C3pResult::InitMatrix()
{
}
