///////////////////////////////////////////////////////////
//  C3pDevOne.cpp
//  Implementation of the Class C3pDevOne
//  Created on:      18-5��-2017 8:21:18
//  Original author: open2
///////////////////////////////////////////////////////////

#include "C3pDevOne.h"


void C3pDevOne::Init()
{
	SetStaCount(1);
	SetDotCount(1);

	InitData();
}