///////////////////////////////////////////////////////////
//  C3pCalOne.h
//  Implementation of the Class C3pCalOne
//  Created on:      18-5��-2017 13:03:56
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_47947345_F270_426c_B6D2_9B0E877E8E5D__INCLUDED_)
#define EA_47947345_F270_426c_B6D2_9B0E877E8E5D__INCLUDED_

#include "C3pCalculate.h"

class C3pCalOne : public C3pCalculate
{

};
#endif // !defined(EA_47947345_F270_426c_B6D2_9B0E877E8E5D__INCLUDED_)
