///////////////////////////////////////////////////////////
//  C3pCalhmcData.h
//  Implementation of the Class C3pCalhmcData
//  Created on:      26-5��-2017 15:40:00
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_CE74E05D_E906_411c_B1A6_E6A089464FBD__INCLUDED_)
#define EA_CE74E05D_E906_411c_B1A6_E6A089464FBD__INCLUDED_

#include "C3pCalculate.h"

class C3pCalhmcData : public C3pCalculate
{

};
#endif // !defined(EA_CE74E05D_E906_411c_B1A6_E6A089464FBD__INCLUDED_)
