#pragma once

#include "C3pRw.h"

class C3pRwTwo : public C3pRw
{

};
