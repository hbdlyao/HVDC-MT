
#include "C3pCalConvertor.h"
//#include "C3pDefs.h"
void C3pCalConvertor::Prepare()
{

}
