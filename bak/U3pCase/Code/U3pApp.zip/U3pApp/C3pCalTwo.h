///////////////////////////////////////////////////////////
//  C3pCalTwo.h
//  Implementation of the Class C3pCalTwo
//  Created on:      18-5��-2017 13:04:04
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_7E6B5869_914C_4d5f_95F8_05041EA23ACA__INCLUDED_)
#define EA_7E6B5869_914C_4d5f_95F8_05041EA23ACA__INCLUDED_

#include "C3pCalculate.h"

class C3pCalTwo : public C3pCalculate
{

};
#endif // !defined(EA_7E6B5869_914C_4d5f_95F8_05041EA23ACA__INCLUDED_)
