#pragma once

#include <string>

using namespace std;

class C3pMain
{
public:
	static void U3pMain();
	static void U3pTest(int vGnd);

	static void U3pCalculate(string vCalName);

};
