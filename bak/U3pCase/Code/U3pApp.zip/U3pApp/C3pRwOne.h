#pragma once


#include "C3pRw.h"

class C3pRwOne : public C3pRw
{

};
