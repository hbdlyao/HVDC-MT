#pragma once

#include "CMyRwDev.h"

#include "C3pDevGrid.h"
#include "C3pDevTBL.h"
#include "CDevBase.h"
#include "gbHead_3pDevice.h"


class C3pRw : public CMyRwDev
{
};
