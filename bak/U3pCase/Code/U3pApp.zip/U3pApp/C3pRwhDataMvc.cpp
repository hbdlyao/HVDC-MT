///////////////////////////////////////////////////////////
//  C3pRwhDataMvc.cpp
//  Implementation of the Class C3pRwhDataMvc
//  Created on:      18-5��-2017 12:45:03
//  Original author: open2
///////////////////////////////////////////////////////////

#include "C3pRwhDataMvc.h"


void C3pRwhDataMvc::Init(C3pDevhmcData* vData)
{
	pData = vData;
}


void C3pRwhDataMvc::doLoad()
{

}


void C3pRwhDataMvc::doSave()
{

}