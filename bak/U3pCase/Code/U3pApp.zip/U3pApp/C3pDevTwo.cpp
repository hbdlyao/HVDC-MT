///////////////////////////////////////////////////////////
//  C3pDevTwo.cpp
//  Implementation of the Class C3pDevTwo
//  Created on:      18-5��-2017 8:21:13
//  Original author: open2
///////////////////////////////////////////////////////////

#include "C3pDevTwo.h"


void C3pDevTwo::Init()
{
	SetStaCount(1);
	SetDotCount(2);

	InitData();
}