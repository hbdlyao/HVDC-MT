#pragma once
#include "C3pCalTwo.h"

class C3pCalSModeData : public C3pCalTwo
{
	void Prepare();

};