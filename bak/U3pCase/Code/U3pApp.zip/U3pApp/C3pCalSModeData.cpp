#include "C3pCalSModeData.h"

void C3pCalSModeData::Prepare()
{

}


