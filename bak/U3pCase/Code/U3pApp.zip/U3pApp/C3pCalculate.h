#pragma once

#include "gbHead_3pType.h"

#include "CPowerCalculate.h"
#include "C3pProfile.h"


class C3pCalculate : public CPowerCalculate
{
protected:
	C3pProfile * p3pProfile;
	C3pOrder * p3pOrder;

	int Index3p;

public:
	void Init(CPowerProfile* vProfile) override;
	
	virtual void InitOrder(C3pOrder * vOrder);
	void Init(CDevBase * vDev) override;


public:
	virtual void Prepare();

	virtual void do3pIndex(ValveMap& vValMap);

	virtual void Update3pData(int vLoop);
};


typedef vector<C3pCalculate*> p3pCalVector;