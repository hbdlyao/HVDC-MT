
#include "C3pCalXf2.h"

void C3pCalXf2::Prepare()
{
}

void C3pCalXf2::Sort3p(ValveMap & vValMap)
{

}

void C3pCalXf2::Update3pData(int vLoop)
{
}
