///////////////////////////////////////////////////////////
//  C3pCalAcSys.h
//  Implementation of the Class C3pCalAcSys
//  Created on:      18-5��-2017 13:04:12
//  Original author: open2
///////////////////////////////////////////////////////////

#if !defined(EA_64B875B6_D78E_4526_9111_7242D9064F6D__INCLUDED_)
#define EA_64B875B6_D78E_4526_9111_7242D9064F6D__INCLUDED_

#include "C3pCalOne.h"

/**
 * ����· ����ϵͳ
 */
class C3pCalAcSys : public C3pCalOne
{

public:
	void Prepare() override;

	virtual void Sort3p(ValveMap& vValMap);

	void Update3pData(int vLoop) override;
};
#endif // !defined(EA_64B875B6_D78E_4526_9111_7242D9064F6D__INCLUDED_)
