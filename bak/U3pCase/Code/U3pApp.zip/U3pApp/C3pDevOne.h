#pragma once


#include "C3pDevBase.h"

class C3pDevOne : public C3pDevBase
{
public:	
	void Init() override;
};
