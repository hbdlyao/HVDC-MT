#pragma once

#include "gbHead_MyType.h"
#include "gbHead_HvdcType.h"


typedef map<string, int> ValveMap;
